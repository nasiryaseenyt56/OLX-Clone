import { Link } from "react-router-dom";

const categories = [
  "All Categories",
  "Mobile Phones",
  "Cars",
  "Motorcycles",
  "Houses",
  "Video-Audios",
  "Tablets",
  "Land & Plots",
];

export const CategoryNav = () => {
  return (
    <nav className="bg-card border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-6 py-3 overflow-x-auto">
          {categories.map((category) => (
            <Link
              key={category}
              to={`/category/${category.toLowerCase().replace(/\s+/g, "-")}`}
              className="text-sm font-medium text-foreground hover:text-primary whitespace-nowrap transition-colors"
            >
              {category}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};
