import { Facebook, Twitter, Instagram, Youtube } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-card border-t border-border mt-12">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-foreground mb-4">POPULAR CATEGORIES</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Cars</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Flats for rent</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Mobile Phones</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Jobs</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-foreground mb-4">TRENDING SEARCHES</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Bikes</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Watches</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Books</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Dogs</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-foreground mb-4">ABOUT US</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">About OLX Group</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Careers</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-foreground mb-4">FOLLOW US</h3>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground hover:bg-primary/90 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground hover:bg-primary/90 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground hover:bg-primary/90 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground hover:bg-primary/90 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© 2025 OLX Pakistan. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
