import { Search, MapPin, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";

export const Header = () => {
  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4 gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <div className="text-3xl font-bold text-primary">
              OLX<span className="text-accent">.</span>
            </div>
          </Link>

          {/* Location */}
          <div className="hidden md:flex items-center gap-2 border border-border rounded-md px-3 py-2 hover:border-primary transition-colors cursor-pointer">
            <MapPin className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium">Pakistan</span>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl relative">
            <Input
              type="text"
              placeholder="Find Cars, Mobile Phones and more..."
              className="pr-12 h-12 border-2"
            />
            <Button
              size="icon"
              className="absolute right-0 top-0 h-12 w-12 rounded-l-none bg-primary hover:bg-primary/90"
            >
              <Search className="w-5 h-5" />
            </Button>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" className="hidden md:flex" asChild>
              <Link to="/login">Login</Link>
            </Button>
            <Button className="bg-accent hover:bg-accent/90 text-primary font-semibold" asChild>
              <Link to="/post-ad">
                <Plus className="w-5 h-5 mr-1" />
                <span className="hidden md:inline">SELL</span>
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};
