import { ListingCard } from "./ListingCard";

const listings = [
  {
    id: 1,
    title: "iPhone 13 Pro Max 256GB",
    price: "Rs 185,000",
    location: "Karachi, Sindh",
    image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400&h=300&fit=crop",
    featured: true,
  },
  {
    id: 2,
    title: "Toyota Corolla 2020 Model",
    price: "Rs 4,500,000",
    location: "Lahore, Punjab",
    image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=400&h=300&fit=crop",
    featured: true,
  },
  {
    id: 3,
    title: "10 Marla House For Sale",
    price: "Rs 12,500,000",
    location: "Islamabad, ICT",
    image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400&h=300&fit=crop",
  },
  {
    id: 4,
    title: "Samsung 55 Inch Smart TV",
    price: "Rs 95,000",
    location: "Rawalpindi, Punjab",
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=300&fit=crop",
  },
  {
    id: 5,
    title: "Honda 125 2021 Model",
    price: "Rs 235,000",
    location: "Karachi, Sindh",
    image: "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=400&h=300&fit=crop",
  },
  {
    id: 6,
    title: "HP Laptop Core i5 8th Gen",
    price: "Rs 55,000",
    location: "Faisalabad, Punjab",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=300&fit=crop",
  },
  {
    id: 7,
    title: "Sony PlayStation 5",
    price: "Rs 125,000",
    location: "Lahore, Punjab",
    image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400&h=300&fit=crop",
  },
  {
    id: 8,
    title: "Canon EOS 90D DSLR Camera",
    price: "Rs 180,000",
    location: "Karachi, Sindh",
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=300&fit=crop",
  },
];

export const FeaturedListings = () => {
  return (
    <section className="py-8 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-foreground">Fresh recommendations</h2>
          <button className="text-primary font-medium hover:underline">
            View more
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {listings.map((listing) => (
            <ListingCard key={listing.id} {...listing} />
          ))}
        </div>
      </div>
    </section>
  );
};
