import { Link } from "react-router-dom";
import { 
  Smartphone, 
  Car, 
  Home, 
  Camera, 
  Bike, 
  Briefcase, 
  Wrench,
  ShoppingBag,
  Sofa,
  Shirt,
  Book,
  Baby
} from "lucide-react";

const categories = [
  { name: "Mobiles", icon: Smartphone, color: "bg-blue-100 text-blue-600" },
  { name: "Vehicles", icon: Car, color: "bg-purple-100 text-purple-600" },
  { name: "Property For Sale", icon: Home, color: "bg-red-100 text-red-600" },
  { name: "Property For Rent", icon: Home, color: "bg-green-100 text-green-600" },
  { name: "Electronics & Home...", icon: Camera, color: "bg-orange-100 text-orange-600" },
  { name: "Bikes", icon: Bike, color: "bg-indigo-100 text-indigo-600" },
  { name: "Business, Industrial...", icon: Briefcase, color: "bg-yellow-100 text-yellow-600" },
  { name: "Services", icon: Wrench, color: "bg-pink-100 text-pink-600" },
  { name: "Jobs", icon: ShoppingBag, color: "bg-cyan-100 text-cyan-600" },
  { name: "Furniture & Home Decor", icon: Sofa, color: "bg-emerald-100 text-emerald-600" },
  { name: "Fashion & Beauty", icon: Shirt, color: "bg-rose-100 text-rose-600" },
  { name: "Books, Sports & Hobbies", icon: Book, color: "bg-violet-100 text-violet-600" },
];

export const CategoryGrid = () => {
  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-foreground mb-6">
          All categories
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link
              key={category.name}
              to={`/category/${category.name.toLowerCase().replace(/\s+/g, "-")}`}
              className="bg-card rounded-lg p-6 hover:shadow-lg transition-all duration-200 border border-border hover:border-primary group"
            >
              <div className={`w-12 h-12 rounded-full ${category.color} flex items-center justify-center mb-3 mx-auto group-hover:scale-110 transition-transform`}>
                <category.icon className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-center text-foreground">
                {category.name}
              </p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};
