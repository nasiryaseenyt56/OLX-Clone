import { Heart } from "lucide-react";
import { Link } from "react-router-dom";

interface ListingCardProps {
  id: number;
  title: string;
  price: string;
  location: string;
  image: string;
  featured?: boolean;
}

export const ListingCard = ({ id, title, price, location, image, featured }: ListingCardProps) => {
  return (
    <Link to={`/listing/${id}`}>
      <div className="bg-card rounded-lg overflow-hidden border border-border hover:shadow-lg transition-all duration-200 group">
        <div className="relative overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {featured && (
            <div className="absolute top-2 left-2 bg-accent text-primary px-2 py-1 rounded text-xs font-bold">
              FEATURED
            </div>
          )}
          <button className="absolute top-2 right-2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
            <Heart className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
        <div className="p-4">
          <h3 className="font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {title}
          </h3>
          <p className="text-xl font-bold text-primary mb-1">{price}</p>
          <p className="text-sm text-muted-foreground">{location}</p>
        </div>
      </div>
    </Link>
  );
};
