import { Header } from "@/components/Header";
import { CategoryNav } from "@/components/CategoryNav";
import { CategoryGrid } from "@/components/CategoryGrid";
import { FeaturedListings } from "@/components/FeaturedListings";
import { Footer } from "@/components/Footer";
import heroBanner from "@/assets/hero-banner.jpg";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <CategoryNav />
      
      <main className="flex-1">
        {/* Hero Banner */}
        <section className="bg-gradient-to-r from-red-500 to-orange-500 relative overflow-hidden">
          <div className="container mx-auto px-4 py-12">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="text-white mb-6 md:mb-0">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">
                  READY TO SELL<br />6X FASTER?
                </h1>
                <p className="text-xl">Feature your ad today!</p>
              </div>
              <div className="relative">
                <img 
                  src={heroBanner} 
                  alt="Hero Banner" 
                  className="w-full max-w-2xl rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        <CategoryGrid />
        <FeaturedListings />
      </main>

      <Footer />
    </div>
  );
};

export default Index;
