import { useParams } from "react-router-dom";
import { Header } from "@/components/Header";
import { CategoryNav } from "@/components/CategoryNav";
import { Footer } from "@/components/Footer";
import { ListingCard } from "@/components/ListingCard";
import { Button } from "@/components/ui/button";
import { SlidersHorizontal } from "lucide-react";

// Sample listings data for different categories
const categoryListings = {
  "mobile-phones": [
    {
      id: 1,
      title: "iPhone 13 Pro Max 256GB",
      price: "Rs 185,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 2,
      title: "Samsung Galaxy S23 Ultra",
      price: "Rs 165,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&h=300&fit=crop",
    },
    {
      id: 3,
      title: "iPhone 14 128GB",
      price: "Rs 195,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1592286927505-4ff845f9f326?w=400&h=300&fit=crop",
    },
    {
      id: 4,
      title: "Xiaomi 13 Pro",
      price: "Rs 95,000",
      location: "Faisalabad, Punjab",
      image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&h=300&fit=crop",
    },
    {
      id: 5,
      title: "OnePlus 11 5G",
      price: "Rs 115,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop",
    },
    {
      id: 6,
      title: "Vivo V27 Pro",
      price: "Rs 75,000",
      location: "Multan, Punjab",
      image: "https://images.unsplash.com/photo-1567581935884-3349723552ca?w=400&h=300&fit=crop",
    },
  ],
  "cars": [
    {
      id: 7,
      title: "Toyota Corolla 2020 Model",
      price: "Rs 4,500,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 8,
      title: "Honda Civic 2019",
      price: "Rs 4,200,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1590362891991-f776e747a588?w=400&h=300&fit=crop",
    },
    {
      id: 9,
      title: "Suzuki Alto 2021",
      price: "Rs 1,850,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1583267746897-d2fe9da29570?w=400&h=300&fit=crop",
    },
    {
      id: 10,
      title: "Toyota Fortuner 2018",
      price: "Rs 7,500,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=400&h=300&fit=crop",
    },
    {
      id: 11,
      title: "Honda City 2020",
      price: "Rs 3,100,000",
      location: "Rawalpindi, Punjab",
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&h=300&fit=crop",
    },
    {
      id: 12,
      title: "Suzuki Cultus 2022",
      price: "Rs 2,450,000",
      location: "Faisalabad, Punjab",
      image: "https://images.unsplash.com/photo-1581540222194-0def2dda95b8?w=400&h=300&fit=crop",
    },
  ],
  "motorcycles": [
    {
      id: 13,
      title: "Honda 125 2021 Model",
      price: "Rs 235,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 14,
      title: "Yamaha YBR 125G",
      price: "Rs 265,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1609630875171-b1321377ee65?w=400&h=300&fit=crop",
    },
    {
      id: 15,
      title: "Suzuki GS 150",
      price: "Rs 285,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=400&h=300&fit=crop",
    },
    {
      id: 16,
      title: "Honda CD 70",
      price: "Rs 115,000",
      location: "Multan, Punjab",
      image: "https://images.unsplash.com/photo-1591568388650-06a4b00e6f00?w=400&h=300&fit=crop",
    },
  ],
  "houses": [
    {
      id: 17,
      title: "10 Marla House For Sale",
      price: "Rs 12,500,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 18,
      title: "5 Marla House DHA",
      price: "Rs 18,000,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=400&h=300&fit=crop",
    },
    {
      id: 19,
      title: "Double Story House",
      price: "Rs 9,500,000",
      location: "Rawalpindi, Punjab",
      image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=400&h=300&fit=crop",
    },
    {
      id: 20,
      title: "Corner House For Sale",
      price: "Rs 15,000,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400&h=300&fit=crop",
    },
  ],
  "tv-video-audio": [
    {
      id: 21,
      title: "Samsung 55 Inch Smart TV",
      price: "Rs 95,000",
      location: "Rawalpindi, Punjab",
      image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 22,
      title: "Sony Home Theater System",
      price: "Rs 45,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop",
    },
    {
      id: 23,
      title: "LG 65 Inch OLED TV",
      price: "Rs 285,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&h=300&fit=crop",
    },
    {
      id: 24,
      title: "JBL Sound Bar",
      price: "Rs 35,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=400&h=300&fit=crop",
    },
  ],
  "tablets": [
    {
      id: 25,
      title: "iPad Air 5th Gen",
      price: "Rs 145,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 26,
      title: "Samsung Galaxy Tab S8",
      price: "Rs 95,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=300&fit=crop",
    },
    {
      id: 27,
      title: "iPad Pro 12.9 inch",
      price: "Rs 225,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1585790050230-5dd28404f905?w=400&h=300&fit=crop",
    },
    {
      id: 28,
      title: "Xiaomi Pad 5",
      price: "Rs 55,000",
      location: "Faisalabad, Punjab",
      image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop",
    },
  ],
  "land-plots": [
    {
      id: 29,
      title: "5 Marla Plot DHA Phase 8",
      price: "Rs 8,500,000",
      location: "Lahore, Punjab",
      image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&h=300&fit=crop",
      featured: true,
    },
    {
      id: 30,
      title: "10 Marla Corner Plot",
      price: "Rs 15,000,000",
      location: "Islamabad, ICT",
      image: "https://images.unsplash.com/photo-1464146072230-91cabc968266?w=400&h=300&fit=crop",
    },
    {
      id: 31,
      title: "1 Kanal Plot Bahria Town",
      price: "Rs 25,000,000",
      location: "Karachi, Sindh",
      image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=400&h=300&fit=crop",
    },
    {
      id: 32,
      title: "8 Marla Residential Plot",
      price: "Rs 6,500,000",
      location: "Rawalpindi, Punjab",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
    },
  ],
};

const categoryTitles: Record<string, string> = {
  "mobile-phones": "Mobile Phones",
  "cars": "Cars",
  "motorcycles": "Motorcycles",
  "houses": "Houses",
  "tv-video-audio": "TV - Video - Audio",
  "tablets": "Tablets",
  "land-plots": "Land & Plots",
  "all-categories": "All Categories",
};

const CategoryPage = () => {
  const { category } = useParams();
  const categoryKey = category || "all-categories";
  
  // Get listings for this category, or all listings if "all-categories"
  const listings = categoryKey === "all-categories" 
    ? Object.values(categoryListings).flat()
    : categoryListings[categoryKey as keyof typeof categoryListings] || [];

  const title = categoryTitles[categoryKey] || "Category";

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <CategoryNav />
      
      <main className="flex-1 bg-background py-8">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">{title}</h1>
              <p className="text-muted-foreground">{listings.length} ads</p>
            </div>
            <Button variant="outline" className="gap-2">
              <SlidersHorizontal className="w-4 h-4" />
              Filters
            </Button>
          </div>

          {listings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {listings.map((listing) => (
                <ListingCard key={listing.id} {...listing} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">No listings found in this category.</p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default CategoryPage;
